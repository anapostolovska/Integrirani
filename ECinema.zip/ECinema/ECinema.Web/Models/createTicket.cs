﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Cinema.Web.Models.DomainModels;

namespace Cinema.Models
{
    public class createTicket
    {
        public Ticket ticket { get; set; }
        public Enumerable<Movie> AllMovies { get; set; }
        public Enumerable<Actor> AllActors { get; set; }
        public Guid movieId { get; set; }
    }
}

