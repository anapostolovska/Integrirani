﻿using System;
using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Cinema.Web.Models;

namespace Cinema.Web.Controllers
{
    public class HomeControllers : Controller
    {
        private readonly ILogger<HomeControllers> _logger;

        public HomeControllers(ILogger<HomeControllers> logger)
        {
            _logger = logger;
        }

        public ActionResult Error()
        {
            var requestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier;
            var errorViewModel = new ErrorViewModel { RequestId = requestId };
            return View(errorViewModel);
        }

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Privacy()
        {
            return View();
        }
    }
}
